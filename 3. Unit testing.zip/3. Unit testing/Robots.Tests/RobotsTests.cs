﻿namespace Robots.Tests
{
    using NUnit.Framework;
    using System;
   

    public class RobotsTests
    {



        [Test]
        public void RobotCtorWokrs()
        {
            Robot rob = new Robot("ime",10);
            Assert.IsNotNull(rob.Name);
            Assert.IsNotNull(rob.Battery);
            Assert.IsNotNull(rob.Battery);
            Assert.That(rob.Name.Equals("ime"));
            Assert.That(rob.Battery.Equals(10));
            Assert.That(rob.MaximumBattery.Equals(10));

        }

        [Test]
        public void RobotManagerCtorWokrs()
        {
           
            RobotManager manager = new RobotManager(10);
            Assert.AreEqual(10, manager.Capacity);

            RobotManager manager2;
            Assert.Throws<ArgumentException>(()=> manager2 = new RobotManager(-2));

        }

        [Test]
        public void RobotManagerCapacityPropertyWorksCorrectly()
        {

           //mislq che go testvam v gorniq metod veche


        }


        [Test]
        public void RobotsManagerCountPropWorksCorrectly()
        {
            Robot rob = new Robot("ime", 10);
            RobotManager manager = new RobotManager(10);
            manager.Add(rob);
            Assert.AreEqual(1, manager.Count);

        }

        [Test]
        public void RobotsManagerAddThrowsIfThereAreTwoRobotsWithTheSameName()
        {
            Robot rob = new Robot("ime", 10);
            Robot rob2 = new Robot("ime", 10);
            RobotManager manager = new RobotManager(10);
            manager.Add(rob);
            Assert.Throws<InvalidOperationException>(() => manager.Add(rob2));

        }

        [Test]
        public void RobotsManagerAddThrowsIfThereIsNotEnoughCapacity()
        {
            Robot rob = new Robot("ime", 10);
            Robot rob2 = new Robot("ime2", 10);
            RobotManager manager = new RobotManager(1);
            manager.Add(rob);

            Assert.Throws<InvalidOperationException>(() => manager.Add(rob2));

        }

        [Test]
        public void RobotsManagerAddWorksProperly()
        {
            Robot rob = new Robot("ime", 10);
            Robot rob2 = new Robot("ime2", 10);
            RobotManager manager = new RobotManager(2);
            manager.Add(rob);
            manager.Add(rob2);
            Assert.AreEqual(manager.Count, 2);

        }

        [Test]
        public void RobotsManagerRemoveWorksProperly()
        {
            Robot rob = new Robot("ime", 10);
            Robot rob2 = new Robot("ime2", 10);
            RobotManager manager = new RobotManager(2);
            manager.Add(rob);
            manager.Add(rob2);

            manager.Remove("ime2");

            Assert.AreEqual(manager.Count, 1);

        }

        [Test]
        public void RobotsManagerRemoveThrows()
        {
            Robot rob = new Robot("ime", 10);
            Robot rob2 = new Robot("ime2", 10);
            RobotManager manager = new RobotManager(2);
            manager.Add(rob);
            manager.Add(rob2);

            Assert.Throws<InvalidOperationException>(() => manager.Remove("ime3"));
        }

            [Test]
        public void RobotsManagerWorkThrowsNullRobot()
        {
            Robot rob = new Robot("ime", 10);
            Robot rob2 = new Robot("ime2", 10);
            RobotManager manager = new RobotManager(2);
            manager.Add(rob);
            manager.Add(rob2);

            Assert.Throws<InvalidOperationException>(() => manager.Work("ime3", "job", 10));
            
        }

        [Test]
        public void RobotsManagerWorkThrowsBatteryNotEnough()
        {
            Robot rob = new Robot("ime", 10);
            Robot rob2 = new Robot("ime2", 10);
            RobotManager manager = new RobotManager(2);
            manager.Add(rob);
            manager.Add(rob2);

            Assert.Throws<InvalidOperationException>(() => manager.Work("ime2", "job", 20));

        }

        [Test]
        public void RobotsManagerWorkWorks()
        {
            Robot rob = new Robot("ime", 10);
            Robot rob2 = new Robot("ime2", 10);
            RobotManager manager = new RobotManager(2);
            manager.Add(rob);
            manager.Add(rob2);
            manager.Work("ime2", "job", 10);

            Assert.AreEqual(rob2.Battery, 0);
        }

        [Test]
        public void RobotsManagerChargeThrowsNullRobot()
        {
            Robot rob = new Robot("ime", 10);
            Robot rob2 = new Robot("ime2", 10);
            RobotManager manager = new RobotManager(2);
            manager.Add(rob);
            manager.Add(rob2);

            Assert.Throws<InvalidOperationException>(() => manager.Charge("ime3"));

        }


        [Test]
        public void RobotsManagerChargeWorks()
        {
            Robot rob = new Robot("ime", 10);
            Robot rob2 = new Robot("ime2", 10);
            RobotManager manager = new RobotManager(2);
            manager.Add(rob);
            manager.Add(rob2);
            manager.Work("ime2","job", 5);
            manager.Charge("ime2");
            Assert.AreEqual(rob2.Battery, 10);

        }

    }
}
